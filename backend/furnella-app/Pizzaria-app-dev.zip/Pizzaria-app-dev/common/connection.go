package common

import (
	"context"
	"log"
	"sync"

	firebase "firebase.google.com/go/v4"
	"firebase.google.com/go/v4/auth"
	"google.golang.org/api/option"
)

var (
	app        *firebase.App
	appOnce    sync.Once
	authClient *auth.Client
)

// initFirebase initializes the Firebase Admin SDK.
func initFirebase() {
	serviceAccountPath := "C:/Goland/Projects/furnella-app/Credentials/furnella-46cj2b-firebase-adminsdk-fbsvc-4f27d73e98.json"

	opt := option.WithCredentialsFile(serviceAccountPath)
	var err error
	config := &firebase.Config{DatabaseURL: "https://furnella-46cj2b-default-rtdb.europe-west1.firebasedatabase.app/"}
	app, err = firebase.NewApp(context.Background(), config, opt)
	if err != nil {
		log.Fatalf("error initializing app: %v\n", err)
	}
}

func GetFirebaseApp() *firebase.App {
	appOnce.Do(initFirebase)
	return app
}
