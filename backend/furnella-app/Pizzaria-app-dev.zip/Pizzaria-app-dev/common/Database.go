package common

import (
	"context"

	db "firebase.google.com/go/v4/db"
)

func GetRealtimeDBClient(ctx context.Context) (*db.Client, error) {
	app := GetFirebaseApp()
	client, err := app.Database(ctx)
	if err != nil {
		return nil, err
	}
	return client, nil
}
