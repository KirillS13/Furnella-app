package handlers

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"myapp/cmd/api/requests"
	"myapp/cmd/api/services"
	"myapp/common"
	"net/http"

	"github.com/labstack/echo/v4"
)

func (h Handler) RegisterHandler(c echo.Context) error {
	payload := new(requests.RegisterRequest)
	if err := c.Bind(payload); err != nil {
		return c.JSON(http.StatusBadRequest, err.Error())
	}

	validationErrors := h.ValidateBodyRequest(c, *payload)
	if validationErrors != nil {
		return c.JSON(http.StatusUnprocessableEntity, validationErrors)
	}

	userService := services.NewUserService(h.DB)
	isEmailTaken, err := userService.IsEmailTaken(payload.Email)
	if err != nil {
		return c.JSON(http.StatusUnprocessableEntity, err.Error())
	}
	if isEmailTaken {
		return c.JSON(http.StatusBadRequest, "Email already taken")
	}
	registeredUser, err := userService.RegisterUser(payload)
	if err != nil {
		return c.JSON(http.StatusBadRequest, err.Error())
	}

	return c.JSON(http.StatusOK, registeredUser)
}

func (h Handler) LoginHandler(c echo.Context) error {
	payload := new(requests.LoginRequest)
	if err := c.Bind(payload); err != nil {
		return c.JSON(http.StatusBadRequest, err.Error())
	}

	validationErrors := h.ValidateBodyRequest(c, *payload)
	if validationErrors != nil {
		return c.JSON(http.StatusUnprocessableEntity, validationErrors)
	}

	url := fmt.Sprintf("https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyDGC1Np-3KhD2rt6QwQhHaiD0E47RxYxQ0")

	data := map[string]interface{}{
		"email":           payload.Email,
		"password":        payload.Password,
		"returnSecureKey": true,
	}
	jsonData, _ := json.Marshal(data)
	resp, err := http.Post(url, "application/json", bytes.NewBuffer(jsonData))
	if err != nil {
		return c.JSON(http.StatusUnprocessableEntity, err.Error())
	}
	defer resp.Body.Close()

	body, _ := ioutil.ReadAll(resp.Body)

	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("login failed: %s", string(body))
	}

	var result common.LoginResponse
	if err = json.Unmarshal(body, &result); err != nil {
		return err
	}
	return common.SendSuccessResponse(c, "User logged in", &result)
}
