package handlers

import (
	"firebase.google.com/go/v4/db"
	"github.com/labstack/echo/v4"
)

type Handler struct {
	DB     *db.Client
	Logger echo.Logger
}
