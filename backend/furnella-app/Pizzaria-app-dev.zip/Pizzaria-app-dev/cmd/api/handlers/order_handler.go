package handlers

import (
	"myapp/cmd/api/requests"
	"myapp/common"
	seeders "myapp/internal/database/Pizza"
	"net/http"

	"github.com/google/uuid"
	"github.com/labstack/echo/v4"
)

func (h Handler) OrderHandler(c echo.Context) error {
	uuID := uuid.New()
	payload := new([]requests.OrderRequest)
	if err := c.Bind(payload); err != nil {
		return c.JSON(http.StatusBadRequest, "Failed to bind payload")
	}
	validationErrors := h.ValidateBodyRequest(c, payload)
	if validationErrors != nil {
		return c.JSON(http.StatusBadRequest, validationErrors)
	}
	var totalPrice int64
	for _, price := range *payload {
		totalPrice += price.Price
	}
	var order = common.OrderResponse{
		OrderID:    uuID.String(),
		Order:      *payload,
		TotalPrice: totalPrice,
	}
	return common.SendSuccessResponse(c, "Good choice!", order)
}

func (h Handler) GetAllPizzas(c echo.Context) error {
	menu := seeders.GetAllPizzas()
	return common.SendSuccessResponse(c, "Меню FURNELLA", menu)
}
