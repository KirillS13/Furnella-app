package handlers

import (
	"fmt"
	"myapp/common"
	"reflect"
	"strconv"
	"strings"

	"github.com/go-playground/validator/v10"
	"github.com/labstack/echo/v4"
)

func (h Handler) ValidateBodyRequest(c echo.Context, payload interface{}) []*common.ValidationError {
	var validate *validator.Validate
	validate = validator.New(validator.WithRequiredStructEnabled())
	var errors []*common.ValidationError
	err := validate.Struct(payload)
	validationErrors, ok := err.(validator.ValidationErrors)
	if ok {
		reflected := reflect.ValueOf(payload)
		for _, validationError := range validationErrors {
			field, _ := reflected.Type().FieldByName(validationError.StructField())

			key := field.Tag.Get("json")

			if key == "" {
				key = strings.ToLower(validationError.StructField())
			}

			condition := validationError.Tag()

			keyToTitleCase := strings.Replace(key, "_", " ", -1)
			param := validationError.Param()
			errMessage := keyToTitleCase + " field is " + condition

			switch condition {
			case "required":
				errMessage = keyToTitleCase + " is required"
			case "min":
				if _, err := strconv.Atoi(param); err == nil {
					errMessage = fmt.Sprintf("%s must be at least %s characters", keyToTitleCase, param)
				}
			case "email":
				errMessage = keyToTitleCase + " is invalid email address"

			case "eqfield":
				errMessage = keyToTitleCase + " must be equal to " + strings.ToLower(param)
			}

			currentValidationError := common.ValidationError{
				Error:     errMessage,
				Key:       keyToTitleCase,
				Condition: condition,
			}

			errors = append(errors, &currentValidationError)
		}
	}
	return errors
}
