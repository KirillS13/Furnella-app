package services

import (
	"context"
	"fmt"
	"myapp/common"
	"time"

	"myapp/cmd/api/requests"
	"myapp/internal/models"

	"firebase.google.com/go/v4/auth"
	"firebase.google.com/go/v4/db"
)

type UserService struct {
	Db   *db.Client
	auth *auth.Client
}

func NewUserService(db *db.Client) *UserService {
	app := common.GetFirebaseApp()

	authClient, err := app.Auth(context.Background())
	if err != nil {
		panic(err)
	}
	return &UserService{
		Db:   db,
		auth: authClient,
	}
}

func (userService *UserService) RegisterUser(request *requests.RegisterRequest) (*models.UserModel, error) {
	params := (&auth.UserToCreate{}).Email(request.Email).Password(request.Password).DisplayName(request.Username)

	u, err := userService.auth.CreateUser(context.Background(), params)
	if err != nil {
		return nil, fmt.Errorf("failed to create user: %w", err)
	}
	user := &models.UserModel{
		ID:        u.UID,
		Username:  request.Username,
		Email:     request.Email,
		Password:  request.Password,
		CreatedAt: time.Now(),
	}
	ref := userService.Db.NewRef("users").Child(user.ID)
	if err := ref.Set(context.Background(), user); err != nil {
		return nil, fmt.Errorf("failed to set user: %w", err)
	}
	return user, nil
}

func (userService *UserService) GetUserByEmail(email string) (*models.UserModel, error) {
	u, err := userService.auth.GetUserByEmail(context.Background(), email)
	if err != nil {
		return nil, fmt.Errorf("failed to get user by email: %w", err)
	}

	ref := userService.Db.NewRef("users").Child(u.UID)
	var user *models.UserModel
	if err := ref.Get(context.Background(), &user); err != nil {
		return nil, fmt.Errorf("failed to get user by email: %w", err)
	}
	return user, nil
}

func (userService *UserService) IsEmailTaken(email string) (bool, error) {
	ref := userService.Db.NewRef("users")
	query := ref.OrderByChild("email").EqualTo(email)
	var result map[string]models.UserModel
	err := query.Get(context.Background(), &result)
	if err != nil {
		return false, fmt.Errorf("IsEmailTaken: %w", err)
	}
	return len(result) > 0, nil
}
