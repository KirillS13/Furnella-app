package main

import (
	"fmt"
	"myapp/cmd/api/handlers"
	"myapp/common"
	"os"

	"github.com/joho/godotenv"
	"github.com/labstack/echo/v4"
	"golang.org/x/net/context"
)

type Application struct {
	handler handlers.Handler
	logger  echo.Logger
	server  *echo.Echo
}

func main() {
	e := echo.New()
	err := godotenv.Load()
	if err != nil {
		e.Logger.Fatal("Failed to load .env file")
	}

	db, err := common.GetRealtimeDBClient(context.Background())
	if err != nil {
		e.Logger.Fatal("Failed to connect to database", err)
	}

	h := handlers.Handler{
		Logger: e.Logger,
		DB:     db,
	}
	app := Application{
		handler: h,
		logger:  e.Logger,
		server:  e,
	}
	app.routes(h)
	fmt.Println(app)
	port := os.Getenv("APP_PORT")
	appAddress := fmt.Sprintf("localhost:%s", port)
	e.Logger.Fatal(e.Start(appAddress))
}
