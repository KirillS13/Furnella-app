package main

import "myapp/cmd/api/handlers"

func (app Application) routes(handler handlers.Handler) {
	app.server.GET("", handler.ServeHTTP)
	app.server.POST("/registration", handler.RegisterHandler)
	app.server.POST("/login", handler.LoginHandler)
	app.server.GET("/order", handler.OrderHandler)
	app.server.GET("/menu", handler.GetAllPizzas)
}
