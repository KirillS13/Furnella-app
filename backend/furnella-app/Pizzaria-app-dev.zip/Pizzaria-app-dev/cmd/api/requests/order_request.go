package requests

type OrderRequest struct {
	Name      string `json:"name" validate:"required"`
	Price     int64  `json:"price" validate:"required"`
	Condition string `json:"condition"`
}
