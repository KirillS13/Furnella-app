package seeders

import (
	"myapp/internal/models"
)

func GetAllPizzas() []models.PizzaModel {
	var menu = []models.PizzaModel{
		{
			Name:        "Итальянский квартал",
			Price:       190,
			Description: "Классическая итальянская пицца с ароматными травами, свежими томатами и нежным сыром моцарелла.",
			ImageURL:    "https://image.png",
		},
		{
			Name:        "Мексиканская",
			Price:       125,
			Description: "Острая пицца с сочным фаршем, перцем халапеньо, кукурузой и сыром — для любителей пикантного вкуса.",
			ImageURL:    "https://image.png",
		},
		{
			Name:        "Тонно",
			Price:       125,
			Description: "Пицца с тунцом, красным луком и сыром моцарелла — лёгкий и насыщенный морской вкус.",
			ImageURL:    "https://image.png",
		},
		{
			Name:        "Лигурия",
			Price:       150,
			Description: "Нежный соус песто, сыр и запечённые овощи — пицца с истинным вкусом итальянского побережья.",
			ImageURL:    "https://image.png",
		},
		{
			Name:        "Тонночипола",
			Price:       150,
			Description: "Тунец, маринованный лук, сыр и фирменный соус — гармония морского вкуса и лёгкой кислинки.",
			ImageURL:    "https://image.png",
		},
		{
			Name:        "Канельяно",
			Price:       150,
			Description: "Сыр, ветчина, грибы и фирменные специи — универсальная пицца для любого случая.",
			ImageURL:    "https://image.png",
		},
		{
			Name:        "Пепперони",
			Price:       150,
			Description: "Классика: много пикантной пепперони и расплавленного сыра. Всегда в топе заказов.",
			ImageURL:    "https://image.png",
		},
		{
			Name:        "Наполи",
			Price:       150,
			Description: "Традиционная пицца с анчоусами, каперсами, оливками и ароматным томатным соусом.",
			ImageURL:    "https://image.png",
		},
		{
			Name:        "Маджоре",
			Price:       140,
			Description: "Ветчина, грибы, сыр и фирменный соус — простой, но идеально сбалансированный вкус.",
			ImageURL:    "https://image.png",
		},
		{
			Name:        "Бонна пицца",
			Price:       115,
			Description: "Нежный сыр, ветчина и свежие томаты — лёгкая и мягкая пицца для всей семьи.",
			ImageURL:    "https://image.png",
		},
		{
			Name:        "Четыре сыра",
			Price:       140,
			Description: "Комбинация моцареллы, дорблю, чеддера и пармезана — сливочный рай для любителей сыра.",
			ImageURL:    "https://image.png",
		},
		{
			Name:        "Бьянка",
			Price:       150,
			Description: "Белая пицца без томатного соуса: сливочная основа, моцарелла, курица и орегано.",
			ImageURL:    "https://image.png",
		},
		{
			Name:        "Полло",
			Price:       125,
			Description: "Сочная курица, сыр, сладкий перец и фирменный соус — вкусно и сытно.",
			ImageURL:    "https://image.png",
		},
		{
			Name:        "Фурнелла",
			Price:       200,
			Description: "Фирменная пицца ресторана: сочные колбаски, бекон, сыр, овощи и секретный соус.",
			ImageURL:    "https://image.png",
		},
		{
			Name:        "Хот дог",
			Price:       190,
			Description: "Пицца со вкусом хот-дога: сосиски, сыр, маринованные огурчики и горчичный соус.",
			ImageURL:    "https://image.png",
		},
		{
			Name:        "Кватро Статей",
			Price:       190,
			Description: "Пицца, разделённая на 4 вкуса: мясная, грибная, овощная и сырная — для тех, кто хочет всё сразу.",
			ImageURL:    "https://image.png",
		},
		{
			Name:        "Мона Лиза",
			Price:       150,
			Description: "Нежный сыр, ветчина, шампиньоны и оливки — тонкий изысканный вкус, как настоящее искусство.",
			ImageURL:    "https://image.png",
		},
		{
			Name:        "Сырный Парус",
			Price:       150,
			Description: "Пицца с двойной порцией сыра, сливочным соусом и тягучей моцареллой — идеал для сыроманов.",
			ImageURL:    "https://image.png",
		},
		{
			Name:        "Бекон",
			Price:       150,
			Description: "Много хрустящего бекона, сыр и дымный аромат — пицца для настоящих мясоедов.",
			ImageURL:    "https://image.png",
		},
	}
	return menu
}
