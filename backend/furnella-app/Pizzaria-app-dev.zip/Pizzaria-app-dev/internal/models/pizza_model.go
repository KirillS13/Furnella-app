package models

type PizzaModel struct {
	Name        string `json:"name"`
	Price       int64  `json:"price"`
	Description string `json:"description"`
	ImageURL    string `json:"image_url"`
}
